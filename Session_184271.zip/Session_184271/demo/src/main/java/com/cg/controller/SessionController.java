package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Session;
import com.cg.exception.SessionException;
import com.cg.service.ISessionService;

@RestController
public class SessionController {
	@Autowired
	private ISessionService service; //creating object for the service interface
	
	/* This method is used to create the table in the database; */
	 
	@RequestMapping(value = "/createSession", method = RequestMethod.POST)
	public List<Session> createProduct(@RequestBody Session session) throws SessionException {
		return  service.createSession(session);
	}
	
	/*This method is used to view all the rows in the table in the database;*/
	@RequestMapping(value = "/viewAllSessions", method = RequestMethod.GET)
	public List<Session> viewAllSessions() {
		return  service.viewAllSession();
	}
	
	/*This method is used to update the rows in the table in the database;*/
	@RequestMapping(value = "/updateSession", method = RequestMethod.POST)
	public Session updateSession(@RequestBody Session session) {
		return  service.updateSession(session);
	}
	
	/*This method is used to delete the rows from  the table based on their Id*/
	@RequestMapping(value = "/delSessions/{id}", method = RequestMethod.DELETE)
	public String delSession(@PathVariable("id") Integer Id) {
		service.delSession(Id);
		return  Id+" is deleted";
	}

}
