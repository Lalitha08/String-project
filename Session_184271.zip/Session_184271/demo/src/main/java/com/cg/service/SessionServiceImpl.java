package com.cg.service;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Session;
import com.cg.dao.ISessionRepo;

import com.cg.exception.ExceptionMessages;
import com.cg.exception.SessionException;

@Service
public class SessionServiceImpl implements ISessionService{
	@Autowired
	ISessionRepo repo;
	/*
	 * created by: Makkena Sowmya 
	 * created date:23/7/19 
	 * Method:create Session and
	 * saving in database
	 */


	@Override
	public List<Session> createSession(Session session) throws SessionException 
	{
		try {
			repo.save(session);
		}catch(Exception exception) {
			throw new SessionException(ExceptionMessages.MESSAGE1);
		}
		
		return  repo.findAll();
		
	}
	/*
	 * created by: Makkena Sowmya 
	 * created date:23/7/19 
	 * Method:viewing all Sessions 
	 *  in the database*/

	@Override
	public List<Session> viewAllSession() {
		
		return  repo.findAll();
	}
	/*
	 * created by: Makkena Sowmya 
	 * created date:23/7/19 
	 * Method:updating the  Session and
	 * saving in database
	 */

	@Override
	public Session updateSession(Session session) {
	
		repo.save(session);
		return session;
	}

	/*
	 * created by: Makkena Sowmya 
	 * created date:23/7/19 
	 * Method:deleting the row from the table using Id;
	 */
	@Override
	public void delSession(Integer Id) {
		
		repo.deleteById(Id);
	}

}
