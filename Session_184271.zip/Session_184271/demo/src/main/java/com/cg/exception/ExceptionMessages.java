package com.cg.exception;

public class ExceptionMessages {

	public static final String MESSAGE1 = null;

}
