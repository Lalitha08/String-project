package com.cg.exception;

public class SessionException extends Exception {
	public SessionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SessionException(String Message) {
		super(Message);
		// TODO Auto-generated constructor stub
	}

}
