package com.cg.service;

import java.util.List;

import com.cg.bean.Session;
import com.cg.exception.SessionException;


public interface ISessionService {
	List<Session>createSession(Session session) throws SessionException;

	List<Session> viewAllSession();

	Session updateSession(Session session);

	void delSession(Integer Id);
	
}

