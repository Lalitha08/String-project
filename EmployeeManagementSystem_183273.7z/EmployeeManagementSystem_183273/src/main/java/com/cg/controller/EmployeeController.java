package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.IEmployeeService;


@RestController
public class EmployeeController {

	@Autowired
	private IEmployeeService service;
	
	
	
	@RequestMapping(value = "/createEmployee", method = RequestMethod.POST)
	public List<Employee> createEmployee(@RequestBody Employee employee) throws EmployeeException{
		return  service.createEmployee(employee);
	}

	@RequestMapping(value = "/delEmployee/{empid}", method = RequestMethod.DELETE)
	public String delEmployee(@PathVariable("empid") Integer empId) throws EmployeeException {
		service.delEmployee(empId);
		return  empId+" is deleted";
	}
	
	
	@RequestMapping(value = "/viewEmployeeList", method = RequestMethod.GET)
	public List<Employee> getAllProducts() {
		return  service.viewEmployeeList();
	}
	
	@RequestMapping(value = "/findEmployeeById/{empid}", method = RequestMethod.GET)
	public Employee findEmployee(@PathVariable("empid") Integer empId) {
		return  service.findEmployeeById(empId);
	}
	
	@RequestMapping(value = "/findEmployeeByDepartment/{department}", method = RequestMethod.GET)
	public List<Employee> viewEmployeeByDepartment(@PathVariable("department") String depart) throws EmployeeException {
		return  service.viewEmployeeByDepartment(depart);
	}
	
	@RequestMapping(value = "/updateEmployee", method = RequestMethod.PUT)
	public Employee updateEmployees(@RequestBody Employee employee) {
		return  service.updateEmployee(employee);
	}
	
}
