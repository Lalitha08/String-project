package com.cg.exception;

public interface ErrorMessages {

String MESSAGE1="data not found";
}
