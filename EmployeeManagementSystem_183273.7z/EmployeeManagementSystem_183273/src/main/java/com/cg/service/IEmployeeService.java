package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;



public interface IEmployeeService {
	List<Employee> createEmployee(Employee employee) throws EmployeeException;
	void delEmployee(Integer empId) throws EmployeeException;
	List<Employee> viewEmployeeList();
	Employee updateEmployee(Employee employee);

	Employee findEmployeeById(Integer empId);
	
	List<Employee> viewEmployeeByDepartment(String dept) throws EmployeeException;

}
