package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.dao.IEmployeeManagementRepo;
import com.cg.exception.EmployeeException;
import com.cg.exception.ErrorMessages;


@Service
public class EmployeeService implements IEmployeeService{
	
	@Autowired
	private IEmployeeManagementRepo repo;

	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException {
		try {
	repo.save(employee);
		}catch (Exception e) {
			throw new EmployeeException(ErrorMessages.MESSAGE1);
		}
		return repo.findAll();
	}

	@Override
	
	public void delEmployee(Integer empId) throws EmployeeException {
		try {
		repo.deleteById(empId);
		}catch (Exception e) {
			throw new EmployeeException(ErrorMessages.MESSAGE1);
		}
	}

	@Override
	public List<Employee> viewEmployeeList() {
	
		return repo.findAll();
	}

	@Override
	public Employee findEmployeeById(Integer empId) {
		
		return repo.getOne(empId);
	}

	@Override
	public List<Employee> viewEmployeeByDepartment(String dept) throws EmployeeException {
		List<Employee> emp=new ArrayList<Employee>();
		
		try {
		List<Employee> employees=repo.findAll();
		
		
		for (Employee employee : employees) {
			if(employee.equals(dept)) {
				emp.add(employee);
			}
		}
		}catch (Exception e) {
			throw new EmployeeException(ErrorMessages.MESSAGE1);
		}
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		
		return repo.save(employee);
	}


	
}
