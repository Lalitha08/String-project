package com.cg.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.exception.ExceptionMessages;
import com.cg.employee.repository.IEmployeeRepo;
@Service
public class EmployeeServiceImpl implements IEmployeeService{
@Autowired
private IEmployeeRepo repo;
	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException{
		// TODO Auto-generated method stub
		
		repo.save(employee);
		
	
		
		return repo.findAll();
	}

	@Override
	public List<Employee> getAllEmployees() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}
	
	@Override
	public Employee updateEmployee(Employee employee,Integer e) {
		// TODO Auto-generated method stub
		Optional<Employee> emp=repo.findById(e);
		Employee emp1=emp.get();
		emp1.setName(employee.getName());
		emp1.setDesignation(employee.getDesignation());
		emp1.setSalary(employee.getSalary());
		emp1.setDeptName(employee.getDeptName());
		
		repo.save(employee);
		return employee;
		
		
	        
	}

	@Override
	public void deleteEmployee(Integer id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}

	@Override
	public Employee findEmployee(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}
	public Employee viewByDeptName(String n) {
		List<Employee> e=repo.findAll();
		for(Employee emp:e) {
			if(emp.getDeptName().equals(n))
				return emp;
		}
		return null;
		
	}

	
	}


