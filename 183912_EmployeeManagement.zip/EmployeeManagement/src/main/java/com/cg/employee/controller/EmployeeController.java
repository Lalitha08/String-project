package com.cg.employee.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.ReadOnlyProperty;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;
import com.cg.employee.service.IEmployeeService;

@RestController
public class EmployeeController {
	@Autowired
	private IEmployeeService service;
@RequestMapping(value = "/create",method=RequestMethod.POST)
	public List<Employee> createEmployee(@RequestBody Employee employee)throws EmployeeException{
		return service.createEmployee(employee);
		
	}
@RequestMapping(value="/get",method = RequestMethod.GET)
public List<Employee> findAll()
{
	return service.getAllEmployees();
}
@RequestMapping(value = "/getbyid/{id}",method = RequestMethod.GET)
public Employee findById(@PathVariable("id") Integer id)
{
	return service.findEmployee(id);
}
@RequestMapping(value = "/updateProduct/{pid}", method = RequestMethod.PUT)
public Employee updateEmployee(@PathVariable(value="eid")Integer e,@RequestBody Employee employee) {
	
	return  service.updateEmployee(employee,e);
}




@RequestMapping(value="/del/{id}",method = RequestMethod.DELETE)
public String deleteEmployee(@PathVariable("id") Integer id)
{
	service.deleteEmployee(id);
	return "hiii";
	
}
@RequestMapping(value="/view/{name}",method=RequestMethod.GET)
public Employee viewByDeptName(@PathVariable("name") String deptName) {
	return service.viewByDeptName(deptName);
}



}
