package com.cg.employee.bean;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import org.springframework.data.annotation.Id;
@Entity
public class Employee implements Serializable{
	@Id
	@GeneratedValue
	private Integer empId;
	private String name;
	private String designation;
	private Double Salary;
	private String deptName;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public Double getSalary() {
		return Salary;
	}
	public void setSalary(Double salary) {
		Salary = salary;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", designation=" + designation + ", Salary=" + Salary
				+ ", deptName=" + deptName + "]";
	}
	public Employee(Integer empId, String name, String designation, Double salary, String deptName) {
		super();
		this.empId = empId;
		this.name = name;
		this.designation = designation;
		Salary = salary;
		this.deptName = deptName;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
