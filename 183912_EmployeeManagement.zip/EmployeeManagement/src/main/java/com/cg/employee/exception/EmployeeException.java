package com.cg.employee.exception;

public class EmployeeException extends Exception{
	public EmployeeException() {
		// TODO Auto-generated constructor stub
	}

}
