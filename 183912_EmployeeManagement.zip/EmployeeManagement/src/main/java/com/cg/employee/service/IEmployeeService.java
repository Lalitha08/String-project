package com.cg.employee.service;

import java.util.List;

import com.cg.employee.bean.Employee;
import com.cg.employee.exception.EmployeeException;

public interface IEmployeeService {
	List<Employee> createEmployee(Employee employee) throws EmployeeException;

	List<Employee> getAllEmployees();

	
	void deleteEmployee(Integer id);

	Employee findEmployee(Integer id);

	Employee updateEmployee(Employee employee, Integer e);
	
	Employee viewByDeptName(String n);

}
