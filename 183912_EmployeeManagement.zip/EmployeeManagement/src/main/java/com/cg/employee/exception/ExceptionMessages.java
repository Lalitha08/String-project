package com.cg.employee.exception;

public interface ExceptionMessages {
	String MESSAGE1="data";

}
