package com.cg.employee.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import com.cg.employee.exception.EmployeeException;


@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(value={EmployeeException.class,Exception.class})

	protected ModelAndView handleConflict(Exception exception) {
		ModelAndView model=new ModelAndView();
		model.addObject("erroerMsg",exception.getMessage());
		model.setViewName("errorPage");
		return model;
				
	}
}
